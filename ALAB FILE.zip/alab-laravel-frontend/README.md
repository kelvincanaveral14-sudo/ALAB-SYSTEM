# ALAB — Responsive Laravel Frontend

**ALAB** means **Advanced Local Administration & Barangay Services**.

**Tagline:** Igniting Progress. Empowering Communities.

This is a frontend-only Laravel Blade package for the ALAB barangay management system. It is designed for PHP + Laravel development using XAMPP and has responsive layouts for phones, tablets, laptops, and desktop monitors.

## Package structure

```text
resources/views/alab/
  admin.blade.php
  resident.blade.php

public/alab/css/
  app.css

public/alab/js/
  admin.js
  resident.js

routes/
  web-routes-snippet.php

preview/
  index.html
  resident.html
  index.php
  resident.php
  assets/css/app.css
  assets/js/admin.js
  assets/js/resident.js
```

## Install into your existing Laravel project

1. Extract this ZIP.
2. Copy `resources/views/alab` into your Laravel project's `resources/views/` folder.
3. Copy `public/alab` into your Laravel project's `public/` folder.
4. Add the route definitions from `routes/web-routes-snippet.php` to your project's `routes/web.php`. Keep any other routes you already use unless they conflict with `/`.
5. From the Laravel project root, run:

```powershell
php artisan optimize:clear
php artisan serve
```

6. Open:
   - Admin dashboard: `http://127.0.0.1:8000/` or `http://127.0.0.1:8000/alab`
   - Resident portal: `http://127.0.0.1:8000/resident-portal`

The Blade templates load files from `public/alab/...` using Laravel's `asset()` helper.

## Quick preview in an existing Laravel project

To run the standalone preview files without Blade routes, copy the contents of this package's `preview` folder into:

```text
C:\xampp\htdocs\alab-system\public\preview\
```

Keep the `assets` subfolder beside `index.php` and `resident.php`. Then open:

- `http://127.0.0.1:8000/preview/index.php`
- `http://127.0.0.1:8000/preview/resident.php`

This quick preview is static demo HTML saved with `.php` filenames; the native Laravel implementation is the Blade views described above.

## Responsive behavior

- Desktop: fixed sidebar, full dashboard grids, full-width tables inside scroll containers.
- Tablet: compact spacing, adjusted cards and single-column dashboard panels when needed.
- Mobile: slide-in admin navigation, collapsible resident navigation, touch-friendly controls, stacked forms, and horizontally scrollable data tables.
- Very narrow phones: single-column cards and service tiles to prevent horizontal page overflow.
- Reduced-motion preference is respected.

## Frontend-only scope

The admin dashboard includes resident records, households, service requests, complaints and suggestions, announcements, reports, users, activity logs, and settings. The resident portal includes online services, request tracking, announcements, and profile information.

There are no migrations, models, controllers, authentication, database queries, or real saving/uploading yet. Displayed records and dashboard numbers are sample data. Forms and controls show demo feedback only.

## ALAB logo

The admin dashboard and resident portal use the same scalable vector logo at `public/alab/images/alab-logo.svg`. The standalone preview uses `preview/assets/images/alab-logo.svg`. To change the logo later, replace these SVG files while keeping the same filenames, or update the image paths in the Blade and preview templates.
