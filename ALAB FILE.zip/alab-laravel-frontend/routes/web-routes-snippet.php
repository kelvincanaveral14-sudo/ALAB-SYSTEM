<?php

use Illuminate\Support\Facades\Route;

// ALAB Admin Dashboard (also serves as the application home page)
Route::view('/', 'alab.admin')->name('alab.home');
Route::view('/alab', 'alab.admin')->name('alab.admin');

// Resident-facing portal
Route::view('/resident-portal', 'alab.resident')->name('alab.resident');
