(function () {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('mobileOverlay');
  const menuToggle = document.getElementById('menuToggle');
  const title = document.getElementById('topPageTitle');

  const pageTitles = {
    dashboard: 'Dashboard Overview',
    residents: 'Resident Management',
    households: 'Household Management',
    requests: 'Service Requests',
    complaints: 'Complaints & Suggestions',
    announcements: 'Community Announcements',
    reports: 'Reports & Analytics',
    users: 'User Management',
    activity: 'Activity Logs',
    settings: 'System Settings'
  };

  function closeSidebar() {
    if (!sidebar || !overlay) return;
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false');
  }

  function openSidebar() {
    if (!sidebar || !overlay) return;
    sidebar.classList.add('open');
    overlay.classList.add('show');
    if (menuToggle) menuToggle.setAttribute('aria-expanded', 'true');
  }

  function showPage(name) {
    if (!pageTitles[name]) return;

    document.querySelectorAll('.page').forEach((page) => {
      page.classList.toggle('active', page.id === `page-${name}`);
    });

    document.querySelectorAll('.nav-link').forEach((navItem) => {
      const active = navItem.dataset.page === name;
      navItem.classList.toggle('active', active);
      if (active) navItem.setAttribute('aria-current', 'page');
      else navItem.removeAttribute('aria-current');
    });

    if (title) title.textContent = pageTitles[name];
    closeSidebar();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  document.querySelectorAll('[data-page]').forEach((element) => {
    element.addEventListener('click', () => showPage(element.dataset.page));
  });

  if (menuToggle) {
    menuToggle.addEventListener('click', () => {
      const isOpen = sidebar && sidebar.classList.contains('open');
      if (isOpen) closeSidebar();
      else openSidebar();
    });
  }

  if (overlay) overlay.addEventListener('click', closeSidebar);

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeSidebar();
      document.querySelectorAll('.modal-backdrop.show').forEach((modal) => modal.classList.remove('show'));
    }
  });

  const toast = document.getElementById('toast');
  let toastTimer;

  function notify(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2600);
  }

  document.querySelectorAll('[data-toast]').forEach((button) => {
    button.addEventListener('click', () => notify(button.dataset.toast));
  });

  const notificationButton = document.getElementById('notificationBtn');
  if (notificationButton) {
    notificationButton.addEventListener('click', () => notify('You have 3 new notifications in this demo.'));
  }

  document.querySelectorAll('[data-modal]').forEach((button) => {
    button.addEventListener('click', () => {
      const modal = document.getElementById(button.dataset.modal);
      if (modal) modal.classList.add('show');
    });
  });

  document.querySelectorAll('[data-close]').forEach((button) => {
    button.addEventListener('click', () => button.closest('.modal-backdrop')?.classList.remove('show'));
  });

  document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
    backdrop.addEventListener('click', (event) => {
      if (event.target === backdrop) backdrop.classList.remove('show');
    });
  });

  document.querySelectorAll('[data-demo-submit]').forEach((button) => {
    button.addEventListener('click', () => {
      button.closest('.modal-backdrop')?.classList.remove('show');
      notify(button.dataset.demoSubmit);
    });
  });

  document.querySelectorAll('[data-table-search]').forEach((input) => {
    input.addEventListener('input', () => {
      const table = document.getElementById(input.dataset.tableSearch);
      if (!table) return;

      const term = input.value.toLowerCase();
      let visible = 0;

      table.querySelectorAll('tbody tr').forEach((row) => {
        const matches = row.innerText.toLowerCase().includes(term);
        row.style.display = matches ? '' : 'none';
        if (matches) visible += 1;
      });

      let empty = table.parentElement.querySelector('.empty-search');
      if (!empty) {
        empty = document.createElement('div');
        empty.className = 'empty-search empty-state';
        empty.textContent = 'No matching records found.';
        table.parentElement.appendChild(empty);
      }
      empty.style.display = visible ? 'none' : 'block';
    });
  });

  const globalSearch = document.getElementById('globalSearch');
  if (globalSearch) {
    globalSearch.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' || !globalSearch.value.trim()) return;
      showPage('residents');
      const search = document.querySelector('[data-table-search="residentTable"]');
      if (search) {
        search.value = globalSearch.value;
        search.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });
  }

  document.querySelectorAll('.settings-menu button').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.settings-menu button').forEach((item) => item.classList.remove('active'));
      button.classList.add('active');
      notify(`${button.textContent.trim()} settings section selected (demo).`);
    });
  });
})();
