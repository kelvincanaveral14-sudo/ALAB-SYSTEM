(function () {
  const modal = document.getElementById('requestModal');
  const type = document.getElementById('serviceType');
  const toast = document.getElementById('residentToast');
  const menuToggle = document.getElementById('portalMenuToggle');
  const portalNav = document.getElementById('portalNav');
  let toastTimer;

  function notify(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2600);
  }

  function closePortalNav() {
    if (!portalNav || !menuToggle) return;
    portalNav.classList.remove('is-open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open resident navigation');
  }

  if (menuToggle && portalNav) {
    menuToggle.addEventListener('click', () => {
      const isOpen = portalNav.classList.toggle('is-open');
      menuToggle.setAttribute('aria-expanded', String(isOpen));
      menuToggle.setAttribute('aria-label', isOpen ? 'Close resident navigation' : 'Open resident navigation');
    });

    portalNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', closePortalNav);
    });

    document.addEventListener('click', (event) => {
      if (!portalNav.contains(event.target) && !menuToggle.contains(event.target)) closePortalNav();
    });
  }

  function openRequest(service) {
    if (!modal) return;
    if (service && type) type.value = service;
    modal.classList.add('show');
    closePortalNav();
  }

  document.querySelectorAll('[data-service]').forEach((button) => {
    button.addEventListener('click', () => openRequest(button.dataset.service));
  });

  const openRequestButton = document.querySelector('[data-open-request]');
  if (openRequestButton) openRequestButton.addEventListener('click', () => openRequest());

  document.querySelectorAll('[data-resident-close]').forEach((button) => {
    button.addEventListener('click', () => modal?.classList.remove('show'));
  });

  if (modal) {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) modal.classList.remove('show');
    });
  }

  const submitRequest = document.getElementById('submitRequest');
  if (submitRequest) {
    submitRequest.addEventListener('click', () => {
      modal?.classList.remove('show');
      notify('Your request is ready for submission in the backend-enabled version.');
    });
  }

  document.querySelectorAll('[data-resident-toast]').forEach((button) => {
    button.addEventListener('click', () => notify(button.dataset.residentToast));
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      modal?.classList.remove('show');
      closePortalNav();
    }
  });
})();
